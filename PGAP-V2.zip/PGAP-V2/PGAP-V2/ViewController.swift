//
//  ViewController.swift
//  PGAP-V2
//
//  Created by Shawn Caeiro on 2/1/16.
//  Copyright © 2016 Shawn Caeiro. All rights reserved.
//

import UIKit
import CoreLocation

class ViewController: UIViewController, CLLocationManagerDelegate {

    @IBOutlet weak var labelB: UILabel!
    @IBOutlet weak var labelA: UILabel!
    var locs: [(Int, String, CLLocation)] = [(0, "Beginning",CLLocation(latitude: 37.330496, longitude: -122.030313)),
        (1, "Second",CLLocation(latitude: 37.330527, longitude: -122.029151)),
        (2, "Third",CLLocation(latitude: 37.330254, longitude: -122.027024)),
        (3, "Fourth",CLLocation(latitude: 37.330223, longitude: -122.024858)),
        (4, "Fifth", CLLocation(latitude: 37.330265, longitude: -122.022969))]
    var locationManager: CLLocationManager!
    var currLocation: CLLocation? = nil
    var currGame = -1
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        locationManager = CLLocationManager();
        locationManager.delegate = self;
        locationManager.desiredAccuracy = kCLLocationAccuracyBest
        locationManager.startUpdatingLocation();
        locationManager.requestAlwaysAuthorization()
        locationManager.startUpdatingLocation()
    }
    
    func locationManager(manager: CLLocationManager, didUpdateLocations locations: [CLLocation]) {
        print(manager.location?.coordinate)
        currLocation = manager.location
        let closestLocation = nearestGame()
        if currGame != closestLocation.0 {
            startGame(closestLocation.0)
            currGame = closestLocation.0
        }
    }
    
    func startGame(game: Int) {
        labelA.text = locs[game].1
    }
    
    func nearestGame() -> (Int, String){
        var closestLocation = (currGame, "")
        var smallestDistance: CLLocationDistance?
        
        for (i, name, loc) in locs {
            let distance = currLocation!.distanceFromLocation(loc)
            if (smallestDistance == nil || distance < smallestDistance) && distance < 20 {
                closestLocation = (i, name)
                smallestDistance = distance
            }
        }
        return closestLocation
    }
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }


}

